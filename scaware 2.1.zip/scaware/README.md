# scaware
una  pequeña demostración de  lo que es  y hace  un saware
